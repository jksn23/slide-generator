# ui-preview

## Overview

Directory-based community: ui

- **Size**: 11 nodes
- **Cohesion**: 0.0787
- **Dominant Language**: python

## Members

| Name | Kind | File | Lines |
|------|------|------|-------|
| PreviewSlideItemWidget | Class | C:\Users\McCrazy\Documents\code\slide-generator\ui\components.py | 4-68 |
| __init__ | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\components.py | 5-8 |
| init_ui | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\components.py | 10-65 |
| on_check_changed | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\components.py | 67-68 |
| MainWindow | Class | C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py | 12-209 |
| __init__ | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py | 13-21 |
| init_ui | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py | 23-158 |
| browse_file | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py | 160-165 |
| generate_preview | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py | 167-189 |
| generate_ppt | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py | 191-209 |
| get_stylesheet | Function | C:\Users\McCrazy\Documents\code\slide-generator\ui\styles.py | 1-108 |

## Execution Flows

- **generate_preview** (criticality: 0.59, depth: 2)
- **generate_ppt** (criticality: 0.43, depth: 1)
- **main** (criticality: 0.40, depth: 1)

## Dependencies

### Outgoing

- `addWidget` (26 edge(s))
- `setProperty` (12 edge(s))
- `QLabel` (11 edge(s))
- `setContentsMargins` (7 edge(s))
- `showMessage` (7 edge(s))
- `statusBar` (7 edge(s))
- `QVBoxLayout` (7 edge(s))
- `setSpacing` (7 edge(s))
- `QWidget` (6 edge(s))
- `setStyleSheet` (5 edge(s))
- `connect` (4 edge(s))
- `addStretch` (4 edge(s))
- `QFrame` (4 edge(s))
- `QHBoxLayout` (3 edge(s))
- `setObjectName` (3 edge(s))

### Incoming

- `C:\Users\McCrazy\Documents\code\slide-generator\ui\components.py` (1 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\main.py::main` (1 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py` (1 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\ui\styles.py` (1 edge(s))
