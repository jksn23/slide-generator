# core-slide

## Overview

Directory-based community: core

- **Size**: 5 nodes
- **Cohesion**: 0.1275
- **Dominant Language**: python

## Members

| Name | Kind | File | Lines |
|------|------|------|-------|
| generate_pptx | Function | C:\Users\McCrazy\Documents\code\slide-generator\core\generator.py | 8-156 |
| SlideType | Class | C:\Users\McCrazy\Documents\code\slide-generator\core\models.py | 5-13 |
| SlideItem | Class | C:\Users\McCrazy\Documents\code\slide-generator\core\models.py | 16-22 |
| parse_docx | Function | C:\Users\McCrazy\Documents\code\slide-generator\core\parser.py | 4-109 |
| flush_buffer | Function | C:\Users\McCrazy\Documents\code\slide-generator\core\parser.py | 19-35 |

## Execution Flows

- **generate_preview** (criticality: 0.59, depth: 2)
- **generate_ppt** (criticality: 0.43, depth: 1)

## Dependencies

### Outgoing

- `RGBColor` (19 edge(s))
- `Inches` (13 edge(s))
- `append` (11 edge(s))
- `Pt` (10 edge(s))
- `upper` (6 edge(s))
- `add_textbox` (3 edge(s))
- `enumerate` (2 edge(s))
- `group` (2 edge(s))
- `startswith` (2 edge(s))
- `Presentation` (1 edge(s))
- `add_slide` (1 edge(s))
- `solid` (1 edge(s))
- `save` (1 edge(s))
- `Enum` (1 edge(s))
- `range` (1 edge(s))

### Incoming

- `C:\Users\McCrazy\Documents\code\slide-generator\core\models.py` (2 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\core\parser.py` (2 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\core\generator.py` (1 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py::MainWindow.generate_ppt` (1 edge(s))
- `C:\Users\McCrazy\Documents\code\slide-generator\ui\main_window.py::MainWindow.generate_preview` (1 edge(s))
