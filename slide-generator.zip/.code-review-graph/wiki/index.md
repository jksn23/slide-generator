# Code Wiki

Auto-generated documentation from the code knowledge graph community structure.

**Total communities**: 2

## Communities

| Community | Size | Link |
|-----------|------|------|
| core-slide | 5 | [core-slide.md](core-slide.md) |
| ui-preview | 11 | [ui-preview.md](ui-preview.md) |
